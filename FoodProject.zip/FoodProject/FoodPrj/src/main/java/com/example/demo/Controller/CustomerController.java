package com.example.demo.Controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DTO.CustomerDTO;
import com.example.demo.DTO.CustomerSaveDTO;
import com.example.demo.Model.CustomerRegister;
import com.example.demo.Service.CustomerService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("api/v1/customer")
public class CustomerController {
	
	@Autowired
	private CustomerService customerService ;
	
	@PostMapping(path="/save")
	public String saveCustomer(@RequestBody CustomerSaveDTO customerSaveDTO )
	{
		String id=customerService.addCustomer(customerSaveDTO);
		return id;
	}
	
	@GetMapping(path="/getAll")
	public List<CustomerDTO>getAllCustomers()
	{
		List<CustomerDTO>allCustomers=customerService.getAllCustomers();
		return allCustomers;
	}
	

	@PutMapping("update/{id}")
	public ResponseEntity<CustomerRegister>updateCustomer(@PathVariable("id")int id,@RequestBody CustomerRegister customer)
	{
		return new ResponseEntity<CustomerRegister>(customerService.updateCustomer(customer, id),HttpStatus.OK);
	}
	
	@DeleteMapping(path="/deleteCustomer/{id}")
	public String deleteCustomer(@PathVariable(value="id")int id)
	{
		boolean deleteCustomer=customerService.deleteCustomer(id);
		return "deleted";
	}
	@GetMapping("/username/{username}")
    public List<CustomerRegister>getAllCustomersByUsername(@PathVariable String username){
    	return customerService.getAllCustomersByUsername(username);
    }

}








