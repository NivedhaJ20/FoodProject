package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DTO.MerchantDTO;
import com.example.demo.DTO.MerchantSaveDTO;
import com.example.demo.Model.Merchant;
import com.example.demo.Service.MerchantService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("api/v1/merchant")
public class MerchantController {
	
	
	@Autowired
	private MerchantService merchantService ;
	
	@PostMapping(path="/save")
	public String saveMerchant(@RequestBody MerchantSaveDTO merchantSaveDTO )
	{
		String id=merchantService.addMerchant(merchantSaveDTO);
		return id;
	}
	
	@GetMapping(path="/getAllMerchant")
	public List<MerchantDTO>getAllMerchant()
	{
		List<MerchantDTO>allMerchant=merchantService.getAllMerchant();
		return allMerchant;
	}
	
	@PutMapping("update/{id}")
	public ResponseEntity<Merchant>updateMerchant(@PathVariable("id")int id,@RequestBody Merchant merchant)
	{
		return new ResponseEntity<Merchant>(merchantService.updateMerchant(merchant, id),HttpStatus.OK);
	}
	
	@DeleteMapping(path="/deleteMerchant/{id}")
	public String deleteMerchant(@PathVariable(value="id")int id)
	{
		boolean deleteMerchant=merchantService.deleteMerchant(id);
		return "deleted";
	}


}

