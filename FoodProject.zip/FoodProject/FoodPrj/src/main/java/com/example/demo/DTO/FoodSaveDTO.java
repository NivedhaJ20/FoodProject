package com.example.demo.DTO;

public class FoodSaveDTO {
	private String FoodName;
	private String foodprice;
	private String foodimage;
	public FoodSaveDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getFoodName() {
		return FoodName;
	}
	public void setFoodName(String foodName) {
		FoodName = foodName;
	}
	public String getFoodprice() {
		return foodprice;
	}
	public void setFoodprice(String foodprice) {
		this.foodprice = foodprice;
	}
	
	public String getFoodimage() {
		return foodimage;
	}
	public void setFoodimage(String foodimage) {
		this.foodimage = foodimage;
	}
	public FoodSaveDTO(String foodName, String foodprice, String foodimage) {
		super();
		FoodName = foodName;
		this.foodprice = foodprice;
		
		this.foodimage = foodimage;
	}
	@Override
	public String toString() {
		return "FoodSaveDTO [FoodName=" + FoodName + ", foodprice=" + foodprice + ",  foodimage=" + foodimage + "]";
	}
	
}
