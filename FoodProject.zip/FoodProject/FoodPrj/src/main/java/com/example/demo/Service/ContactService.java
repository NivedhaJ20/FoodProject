package com.example.demo.Service;

import java.util.List;

import com.example.demo.DTO.ContactDTO;
import com.example.demo.DTO.ContactSaveDTO;
import com.example.demo.Model.Contact;

public interface ContactService {
	String addContact(ContactSaveDTO contacsaveDTO );
	List<ContactDTO>getAllContact();
	boolean deleteContact(int id);
}

