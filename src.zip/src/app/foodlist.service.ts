import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Foodlist } from './foodlist';


@Injectable({
  providedIn: 'root'
})
export class FoodlistService {
  private baseURL="http://localhost:8083/api/v1/foodlist"
  constructor(private httpClient:HttpClient) { }
  createFood(food:Foodlist):Observable<Object>
  {
    return this.httpClient.post(`${this.baseURL}/${'save'}`,food)
  }
  getfoodList():Observable<Foodlist>
  {
    return this.httpClient.get<Foodlist>(`${this.baseURL}/${'getAll'}`)
  }
  updatefoodList(id:number,foodlist:Foodlist):Observable<Object>
  {
    return this.httpClient.put(`${this.baseURL}/${'update'}/${id}`,foodlist);
  }
  deletefoodList(id:number):Observable<Object>
  {
    return this.httpClient.delete(`${this.baseURL}/${'deleteFood'}/${id}`);
  }
  getfoodListById(id:number):Observable<Foodlist>
{
  return this.httpClient.get<Foodlist>(`${this.baseURL}/${id}`);


}
  
}