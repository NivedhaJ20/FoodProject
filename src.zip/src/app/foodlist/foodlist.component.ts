import { Component, OnInit } from '@angular/core';
import {  Router } from '@angular/router';
import { FoodlistService } from '../foodlist.service';
import { Foodlist } from '../foodlist';

@Component({
  selector: 'app-foodlist',
  templateUrl: './foodlist.component.html',
  styleUrls: ['./foodlist.component.css']
})
export class FoodlistComponent implements OnInit {
  food:Foodlist=new Foodlist();
constructor(protected foodservice:FoodlistService,private router:Router){}
ngOnInit(): void {
    
  }

savefood()
{
  this.foodservice.createFood(this.food).subscribe((data:any)=>
  {
     console.log(data);
    
  },
  (error:any)=>console.log(error));
  }

  onSubmit()
  {
    console.log(this.food);
    this.savefood();
    this.router.navigate(['foodlist'])
  }
}