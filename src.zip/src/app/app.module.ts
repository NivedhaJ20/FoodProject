import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactComponent } from './contact/contact.component';
import { GalleryComponent } from './gallery/gallery.component';
import { HomePageComponent } from './home-page/home-page.component';
import { FirstpageComponentComponent } from './firstpage-component/firstpage-component.component';
import { OrderComponent } from './order/order.component';
import { RegisterComponent } from './register/register.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponentComponent } from './login-component/login.component';
import { PaymentComponent } from './payment/payment.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { FoodlistComponent } from './foodlist/foodlist.component';
import { ListfoodComponent } from './listfood/listfood.component';
import { UserListComponent } from './userlist/userlist.component';




@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    AboutUsComponent,
    ContactComponent,
    GalleryComponent,
    HomePageComponent,
    FirstpageComponentComponent,
    OrderComponent,
    RegisterComponent,
  LoginComponentComponent,
  PaymentComponent,
  AdminhomeComponent,
  FoodlistComponent,
  ListfoodComponent,
  UserListComponent
  
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }