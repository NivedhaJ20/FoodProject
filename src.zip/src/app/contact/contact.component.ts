import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ContactService } from '../contact.service';
 

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent {
  con: FormGroup;
  nameisRequired: boolean = false;
  emailisRequired: boolean = false;
  phoneNumisRequired: boolean = false;
  MessageisRequired: boolean = false;
  constructor(private router: Router, private regForm: FormBuilder, private conService: ContactService) {
    this.con = new FormGroup({
      name: new FormControl('',Validators.required),
      email: new FormControl('', Validators.required),
      phoneno: new FormControl('', Validators.required),
      message: new FormControl('', Validators.required),
    })
  }
  ngOnInit() {

  }

  consubmit() {
    if (this.con.valid) {
      this.nameisRequired=false;
      this.emailisRequired=false;
      this.MessageisRequired=false;
      this.phoneNumisRequired=false;
      var formData = this.con.value;
      this['conService'].createContact(formData).subscribe(res => {
        console.log(res);
        if (res) {


        }
     
      })
      this.router.navigate(['']);
    }
    else {
      if(this.con.controls['name'].value == ''){
        this.nameisRequired = true;
      }
      else{
        this.nameisRequired=false;
      }
      if (this.con.controls['email'].value == '') {
        this.emailisRequired = true;
      }
      else{
        this.emailisRequired=false;
      }
      if(this.con.controls['phoneno'].value ==''){
        this.phoneNumisRequired=true;
      }
      else{
        this.phoneNumisRequired=false;
      }
      if(this.con.controls['message'].value==''){
        this.MessageisRequired=true;
      }
      else{
        this.MessageisRequired=false;
      }
    }



  }
}