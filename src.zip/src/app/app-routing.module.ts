import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactComponent } from './contact/contact.component';
import { FirstpageComponentComponent } from './firstpage-component/firstpage-component.component';
import { GalleryComponent } from './gallery/gallery.component';
import { HomePageComponent } from './home-page/home-page.component';
import { MenuComponent } from './menu/menu.component';
import { RegisterComponent } from './register/register.component';
import { FormsModule } from '@angular/forms';
import { OrderComponent } from './order/order.component';
import { LoginComponentComponent } from './login-component/login.component';
import { PaymentComponent } from './payment/payment.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { FoodlistComponent } from './foodlist/foodlist.component';
import { ListfoodComponent } from './listfood/listfood.component';
import { UserListComponent } from './userlist/userlist.component';

const routes: Routes = [
  {
    path:'',
    component:FirstpageComponentComponent
  },
  {
    path:'login',
    component:LoginComponentComponent
  },
  {
    path:'register',
    component:RegisterComponent
  },
  {
    path:'homepage',
    component:HomePageComponent
  },
  {
    path:'aboutUs',
    component:AboutUsComponent
  },
  {
    path:'gallery',
    component:GalleryComponent
  },
  {
    path:'menu',
  component:MenuComponent

  },
  {
    path:'orderdetails',
  component:OrderComponent

  },
  
  {
    path:'contact',
    component:ContactComponent
  },
  {
    path:'home',
    component:HomePageComponent
  },
  { 
    path:'payment',
    component:PaymentComponent
  },
{
  path:'adminhome',
  component:AdminhomeComponent
},
{
  path:'foodlist',
  component:ListfoodComponent
},
{
  path:'addfood',
  component:FoodlistComponent
},
{
  path:'userlist',
  component:UserListComponent
}
  
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
