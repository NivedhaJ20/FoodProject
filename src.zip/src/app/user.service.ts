import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Userlist } from './userlist';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private baseURL="http://localhost:8083/api/v1/customer"
  constructor(private httpClient:HttpClient) { }
  getUserList():Observable<Userlist>
  {
    return this.httpClient.get<Userlist>(`${this.baseURL}/${'getAll'}`)
  }
  deleteUSerList(id:number):Observable<Object>
  {
    return this.httpClient.delete(`${this.baseURL}/${'deleteCustomer'}/${id}`);
  }
}