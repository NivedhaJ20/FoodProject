import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit{
  getFood:any;
  foodList:FormGroup;
  foodPrice:any;
  constructor(private router:Router,){
    this.foodList = new FormGroup({
      Formfoodnames: new FormControl(''),
      FormfoodPrice: new FormControl(''),
      formTotalprice: new FormControl('')
    })
  }
  ngOnInit() {
    this.getFood=localStorage.getItem('foodName')
    var foodname = this.getFood.split(',')
    var food = foodname[0];
    this.foodPrice = foodname[1];
    this.foodList.controls['Formfoodnames'].setValue(food);
    this.foodList.controls['FormfoodPrice'].setValue(this.foodPrice);
    console.log(this.getFood);
  }
  payRoute(){
    this.router.navigate(['payment'])
  }
  quantity(data:any){
    var foodQty = data.target.value;
    var totalPrice = (this.foodPrice*foodQty);
    this.foodList.controls['formTotalprice'].setValue(totalPrice);
  }
}