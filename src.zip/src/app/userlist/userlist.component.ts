import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.css']
})
export class UserListComponent implements OnInit {
userList:any;
constructor(private userService: UserService,private router:Router){
this.getUserList();
}
  ngOnInit(): void {
  
  }
  getUserList(){
    this.userService.getUserList().subscribe(res=>{
      console.log(res)
      this.userList=res;
    })
  }

  
  Ondeleted(id:number){
this.userService.deleteUSerList(id).subscribe(data=>{
  console.log(data)
  this.getUserList();

})
  }
  back() {
    this.router.navigate(['adminhome'])
  }

}