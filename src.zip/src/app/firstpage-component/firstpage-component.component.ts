import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-firstpage-component',
  templateUrl: './firstpage-component.component.html',
  styleUrls: ['./firstpage-component.component.css']
})
export class FirstpageComponentComponent {

  constructor(private router:Router){

  }
  ngOnit(){

  }
  loginroute(){
this.router.navigate(['login'])
  }
  registerroute(){
    this.router.navigate(['register'])
  }
}