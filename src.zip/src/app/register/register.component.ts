import { NgIf } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { RegisterService } from '../register.service';



@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  reg: FormGroup;
  isRequired: boolean = false;
  constructor(private router: Router, private regForm: FormBuilder, private regService:RegisterService) {
    this.reg = new FormGroup({
      firstname: new FormControl(''),
      lastname: new FormControl(''),
      username: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required),
      email: new FormControl('',Validators.required),
      phoneNo: new FormControl('',Validators.required),
      location: new FormControl(''),
    })
  }
  ngOnInit() {

  }
  back() {
    this.router.navigate([''])
  }
  submit() {
    if (this.reg.valid) {
      this.isRequired = false
      var formData = this.reg.value
      this.regService.createRegister(formData).subscribe(res=>{
        if(res){
         
        }
      })
      this.router.navigate(['login'])
      console.log(this.reg.value);
    }
    else {
      this.isRequired = true
    }

  }
}