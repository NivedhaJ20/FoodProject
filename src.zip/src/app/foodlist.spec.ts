import { Foodlist } from './foodlist';

describe('Foodlist', () => {
  it('should create an instance', () => {
    expect(new Foodlist()).toBeTruthy();
  });
});
