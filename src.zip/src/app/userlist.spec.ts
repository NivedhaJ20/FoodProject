import { Userlist } from './userlist';

describe('Userlist', () => {
  it('should create an instance', () => {
    expect(new Userlist()).toBeTruthy();
  });
});
